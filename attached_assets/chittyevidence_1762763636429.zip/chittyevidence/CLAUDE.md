# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**ChittyEvidence** (Marie Kondo Evidence System) is an automated evidence management system that organizes, verifies, and tracks legal evidence with blockchain integration. Built specifically for the Arias v Bianchi case, it provides continuous monitoring of evidence files with full chain-of-custody tracking and integration with the ChittyOS ecosystem.

**Key Characteristic:** This is a Python-based daemon system that automatically processes legal evidence files as they arrive, unlike the TypeScript/Cloudflare Workers services in the parent ecosystem.

## Architecture

### Core Components

1. **daemon.py** - Always-on file system watcher
   - Monitors `incoming/` directory continuously
   - Auto-processes new evidence files
   - Generates evidentiary documents every 5 minutes
   - Uses `watchdog` library for file system events

2. **evidence_core.py** - Core processing engine
   - `EvidenceProcessor` - Main file processing and categorization
   - `ChittyIntegration` - PostgreSQL database integration (Neon)
   - SHA256 hashing for duplicate detection
   - Symlink-based organization preserving originals

3. **chitty_integrations.py** - ChittyOS ecosystem integrations
   - `ChittyChainIntegration` - Blockchain evidence storage
   - `ChittyVerifyIntegration` - Document authenticity verification
   - `ChittyTrustIntegration` - Trust scoring
   - `ChittyIDIntegration` - Identity verification
   - `ChittyPlatformManager` - Unified manager for all services

4. **evidence_cli.py** - Command-line interface
   - Manual evidence operations
   - Search and query capabilities
   - Chain of custody viewing
   - System status and statistics

### Data Flow

1. Files dropped into `incoming/` directory
2. Daemon detects new file via `watchdog`
3. SHA256 hash calculated for duplicate detection
4. Evidence categorized using filename/content analysis
5. Original moved to `.originals/` with hash prefix
6. Symlink created in appropriate category folder
7. Evidence registered in Neon PostgreSQL database
8. Optional: ChittyChain blockchain storage, ChittyVerify authenticity check, ChittyTrust scoring
9. Event logged in `evidence_events` table
10. Notifications sent via webhook if configured

## Essential Commands

### Setup and Installation

```bash
# Initial setup (creates directory structure)
./setup.sh

# Full installation to specific location
./install.sh

# Manual configuration
cp config/.env.example config/.env
nano config/.env  # Edit database URL and settings
```

### Starting/Stopping the Daemon

**macOS:**
```bash
# Load the service
launchctl load ~/Library/LaunchAgents/com.mariekondo.evidence.plist

# Check status
launchctl list | grep mariekondo

# Stop the service
launchctl unload ~/Library/LaunchAgents/com.mariekondo.evidence.plist

# View logs
tail -f logs/marie_kondo.log
```

**Linux:**
```bash
# Enable and start
systemctl --user enable --now mariekondo-evidence

# Check status
systemctl --user status mariekondo-evidence

# Stop
systemctl --user stop mariekondo-evidence

# View logs
journalctl --user -u mariekondo-evidence -f
```

**Manual daemon execution (for testing):**
```bash
python3 bin/daemon.py
```

### CLI Commands

```bash
# Process a specific file manually
python3 bin/evidence_cli.py process /path/to/file.pdf

# Search evidence
python3 bin/evidence_cli.py search --category "01_TRO_PROCEEDINGS"
python3 bin/evidence_cli.py search --tag "affidavit"
python3 bin/evidence_cli.py search --from-date 2024-10-01 --to-date 2024-10-31

# View system status
python3 bin/evidence_cli.py status

# View chain of custody
python3 bin/evidence_cli.py chain <file_hash>

# View statistics
python3 bin/evidence_cli.py stats
```

### Database Operations

```bash
# Test database connection
psql $DATABASE_URL -c "SELECT 1"

# View evidence count
psql $DATABASE_URL -c "SELECT COUNT(*) FROM evidence_registry WHERE chitty_id='arias_v_bianchi_2024D007847';"

# View recent evidence
psql $DATABASE_URL -c "SELECT exhibit_id, original_name, category, created_at FROM evidence_registry ORDER BY created_at DESC LIMIT 10;"

# View chain of custody for specific evidence
psql $DATABASE_URL -c "SELECT event_type, timestamp FROM evidence_events WHERE file_hash='<hash>' ORDER BY timestamp;"
```

### Python Dependencies

```bash
# Install all required packages
pip3 install watchdog psycopg2-binary python-dotenv requests schedule

# Or via requirements.txt (if created)
pip3 install -r requirements.txt
```

## Directory Structure

```
chittyevidence/
├── bin/                        # Executables
│   ├── daemon.py              # Main daemon process
│   └── evidence_cli.py        # CLI tool
├── lib/                       # Core libraries
│   ├── evidence_core.py       # Processing logic and DB integration
│   └── chitty_integrations.py # ChittyOS ecosystem integrations
├── config/                    # Configuration
│   └── .env                   # Environment variables
├── data/                      # Local data storage
├── logs/                      # Application logs
├── incoming/                  # Drop new evidence here (monitored)
└── lockbox/                   # Organized evidence vault
    ├── .originals/            # Actual files (hash-prefixed)
    ├── 00_KEY_EXHIBITS/       # High-priority evidence
    ├── 00_EVIDENCE_INDEX/     # Auto-generated indexes
    ├── 00_CASE_TIMELINE/      # Auto-generated timeline
    ├── 01_TRO_PROCEEDINGS/    # Category folders (symlinks)
    ├── 02_LLC_FORMATION/
    ├── 03_MEMBERSHIP_REMOVAL/
    ├── 04_PREMARITAL_FUNDING/
    ├── 05_PROPERTY_TRANSACTIONS/
    ├── 06_FINANCIAL_STATEMENTS/
    ├── 07_COURT_FILINGS/
    ├── 08_ATTORNEY_CORRESPONDENCE/
    ├── 09_PERJURY_EVIDENCE/
    ├── 10_SANCTIONS_RULE137/
    ├── 11_COLOMBIAN_PROPERTY/
    ├── 12_LEASE_AGREEMENTS/
    ├── 98_DUPLICATES/         # Duplicate detection
    └── 99_UNSORTED/           # Uncategorized files
```

## Database Schema

### evidence_registry
Primary evidence tracking table:
- `id` - Serial primary key
- `chitty_id` - Case identifier (e.g., "arias_v_bianchi_2024D007847")
- `file_hash` - SHA256 hash (UNIQUE constraint for duplicate prevention)
- `original_name` - Original filename
- `exhibit_id` - Generated exhibit ID (e.g., "EX001_20241031_document.pdf")
- `category` - Category folder (e.g., "01_TRO_PROCEEDINGS")
- `tags` - JSONB array of tags
- `metadata` - JSONB metadata (file size, mime type, processing info)
- `chain_of_custody` - JSONB custody chain
- `created_at` - Registration timestamp
- `updated_at` - Last update timestamp

### evidence_relationships
Links between related evidence:
- `id` - Serial primary key
- `chitty_id` - Case identifier
- `parent_hash` - Parent evidence hash (FK to evidence_registry)
- `child_hash` - Child evidence hash (FK to evidence_registry)
- `relationship_type` - Type (e.g., "response", "amendment", "exhibit")
- `metadata` - JSONB additional data
- `created_at` - Relationship creation time

### evidence_events
Complete audit trail:
- `id` - Serial primary key
- `chitty_id` - Case identifier
- `file_hash` - Evidence hash (FK to evidence_registry)
- `event_type` - Event type (e.g., "registered", "accessed", "modified", "verified")
- `event_data` - JSONB event details
- `user_id` - User identifier (optional)
- `timestamp` - Event timestamp

### Key Indexes
- `idx_evidence_chitty_id` - Fast case filtering
- `idx_evidence_category` - Category queries
- `idx_evidence_tags` - GIN index for JSONB tag searches
- `idx_events_timestamp` - Chronological event queries

## Configuration

Key environment variables in `config/.env`:

### Required Settings
```bash
DATABASE_URL=postgresql://user:password@host.neon.tech:5432/chittyledger
CHITTY_ID=arias_v_bianchi_2024D007847
INCOMING_DIR=/path/to/incoming
LOCKBOX_DIR=/path/to/lockbox
```

### Processing Options
```bash
AUTO_PROCESS=true              # Auto-process files in incoming/
DUPLICATE_CHECK=true           # SHA256 duplicate detection
CREATE_SYMLINKS=true           # Create category symlinks
UPDATE_INTERVAL=300            # Document rebuild interval (seconds)
```

### ChittyOS Integration (Optional)
```bash
# ChittyChain - Blockchain evidence storage
CHITTYCHAIN_API=https://api.chittychain.com
CHITTYCHAIN_API_KEY=your_key

# ChittyVerify - Document verification
CHITTYVERIFY_API=https://api.chittyverify.com
CHITTYVERIFY_API_KEY=your_key

# ChittyTrust - Trust scoring
CHITTYTRUST_API=https://api.chittytrust.com
CHITTYTRUST_API_KEY=your_key

# ChittyID - Identity verification
CHITTYID_API=https://id.chitty.cc
CHITTYID_API_KEY=your_key
```

### Notifications
```bash
NOTIFY_ON_NEW_EVIDENCE=true
WEBHOOK_URL=https://hooks.chitty.services/evidence-updates
```

### Logging
```bash
LOG_LEVEL=INFO                 # DEBUG, INFO, WARNING, ERROR
LOG_FILE=logs/marie_kondo.log
```

## Key Patterns and Conventions

### Exhibit ID Format
Generated as: `EX{number}_{date}_{cleanname}{extension}`
- Example: `EX001_20241031_affidavit_filed.pdf`
- Sequential numbering per category
- Date extracted from filename if present, else "UNDATED"
- Clean name truncated to 30 characters, underscored

### File Hash Storage
- Originals stored in `.originals/` with format: `{hash_prefix}_{original_filename}`
- Hash prefix is first 8 characters of SHA256
- Example: `.originals/a1b2c3d4_document.pdf`

### Automatic Categorization
Categories determined by filename matching:
- TRO keywords → `01_TRO_PROCEEDINGS`
- Corporate/LLC keywords → `02_LLC_FORMATION`
- Membership keywords → `03_MEMBERSHIP_REMOVAL`
- Funding/premarital → `04_PREMARITAL_FUNDING`
- Property/deed/mortgage → `05_PROPERTY_TRANSACTIONS`
- Financial/bank → `06_FINANCIAL_STATEMENTS`
- Court/motion/petition → `07_COURT_FILINGS`
- Attorney/legal correspondence → `08_ATTORNEY_CORRESPONDENCE`
- Perjury/false statement → `09_PERJURY_EVIDENCE`
- Sanctions/rule-137 → `10_SANCTIONS_RULE137`
- Colombia/morada-mami → `11_COLOMBIAN_PROPERTY`
- Lease/rental → `12_LEASE_AGREEMENTS`
- No match → `99_UNSORTED`

### Tag Extraction
Automatically extracted from filenames:
- Date patterns: `YYYY-MM-DD` → `date:2024-10-31`
- Legal terms: affidavit, exhibit, deposition, transcript, order, motion, petition, response
- Category-specific tags from `categories` dict in `evidence_core.py`

### Chain of Custody Events
Standard event types:
- `registered` - Initial evidence registration
- `accessed` - Evidence accessed/viewed
- `modified` - Metadata modified
- `verified` - Verification completed
- `tags_added` - Tags added to evidence
- `blockchain_stored` - Stored on ChittyChain
- `trust_scored` - Trust score calculated

### Document Auto-Generation
Every 5 minutes (configurable), daemon generates:
1. **Case Timeline** (`00_CASE_TIMELINE/auto_timeline.md`)
   - Chronological evidence listing
   - Grouped by date with exhibit IDs and descriptions

2. **Key Documents Index** (`00_KEY_EXHIBITS/key_documents_index.md`)
   - High-priority evidence grouped by category
   - Chain of custody event counts

3. **Chain of Custody Report** (`00_EVIDENCE_INDEX/chain_of_custody.json`)
   - Complete JSON export of all custody chains
   - Forensically suitable format

## Development Workflow

### Adding New Evidence Categories

1. Add category to `categories` dict in `evidence_core.py`:
```python
"13_NEW_CATEGORY": {
    "name": "Category Name",
    "tags": ["tag1", "tag2"],
    "priority_keywords": ["keyword1", "keyword2"]
}
```

2. Create directory:
```bash
mkdir -p lockbox/13_NEW_CATEGORY
```

3. Update categorization logic in `categorize_enhanced()` method if needed

### Adding New ChittyOS Integrations

1. Create integration class in `chitty_integrations.py`:
```python
class ChittyNewServiceIntegration:
    def __init__(self, api_endpoint: str, api_key: str):
        # Implementation
```

2. Add to `ChittyPlatformManager.__init__()`:
```python
if config.get("CHITTYNEWSERVICE_API"):
    self.chitty_newservice = ChittyNewServiceIntegration(...)
```

3. Integrate in `process_evidence_comprehensive()` method

4. Add configuration to `.env.example`

### Testing Evidence Processing

```bash
# 1. Start daemon in foreground for debugging
python3 bin/daemon.py

# 2. In another terminal, copy test file
cp test_document.pdf incoming/

# 3. Watch logs
tail -f logs/marie_kondo.log

# 4. Verify database entry
psql $DATABASE_URL -c "SELECT * FROM evidence_registry WHERE original_name='test_document.pdf';"

# 5. Check symlink creation
ls -la lockbox/*/test_document.pdf
```

### Debugging Common Issues

**Daemon won't start:**
- Check logs: `cat logs/marie_kondo.log`
- Verify Python dependencies: `pip3 list | grep -E "watchdog|psycopg2|dotenv"`
- Test database connection: `psql $DATABASE_URL`
- Check directory permissions

**Files not processing:**
- Verify file is supported type: `.pdf, .doc, .docx, .txt, .jpg, .png`
- Check incoming directory path in `.env`
- Look for errors in logs
- Ensure daemon is running: `launchctl list | grep mariekondo` (macOS)

**Database connection errors:**
- Test connection: `psql $DATABASE_URL -c "SELECT 1"`
- Verify `DATABASE_URL` format in `.env`
- Check network connectivity to Neon
- Ensure database has required tables (run `ChittyIntegration.create_evidence_tables()`)

**ChittyOS integration failures:**
- Verify API endpoints are accessible
- Check API keys are valid
- Review integration-specific logs
- Services are optional - system works without them

## Integration with Parent ChittyOS Ecosystem

This project connects to the broader ChittyOS ecosystem:

### Shared Database
- Uses same Neon PostgreSQL as other ChittyOS services
- Tables prefixed with `evidence_` to avoid conflicts
- Shares `CHITTY_ID` for case linking

### Service Integrations
- **ChittyID** - Identity verification for case participants
- **ChittyChain** - Blockchain evidence storage for immutability
- **ChittyVerify** - Document authenticity and tampering detection
- **ChittyTrust** - Trust scoring for evidence reliability
- **ChittyLedger** - PostgreSQL database for evidence registry

### Authentication
Unlike TypeScript services, this Python system:
- Requires API keys in `.env` for ChittyOS services
- No JWT token validation (operates as trusted local system)
- Direct database access via `DATABASE_URL`

## Case-Specific Context

Built specifically for **Arias v Bianchi** (Case ID: `arias_v_bianchi_2024D007847`):
- 12 pre-configured evidence categories
- TRO proceedings starting 2024-10-30
- LLC formation and membership removal focus
- Perjury and sanctions tracking (Rule 137)
- Colombian property evidence
- Pre-marital funding documentation

Categories are customizable for other cases by modifying `categories` dict.

## Critical Constraints

1. **File preservation** - Never delete files, only archive
2. **Hash uniqueness** - SHA256 enforces no duplicates
3. **Symlink organization** - Originals always in `.originals/`
4. **Continuous operation** - Daemon must run 24/7 for monitoring
5. **Database consistency** - All changes committed transactionally
6. **Case isolation** - Filter by `chitty_id` for multi-case support
7. **Chain of custody** - Every action logged in `evidence_events`
