/**
 * ChittySchema - Type Definitions for ChittyOS Ecosystem
 *
 * Usage:
 * import { chittyledger, chittyos_core } from '@chittyos/schema';
 *
 * const evidence: chittyledger.Evidence = { ... };
 * const identity: chittyos_core.Identities = { ... };
 */

export * as chittyledger from './chittyledger/index.js';
export * as chittyos_core from './chittyos-core/index.js';
